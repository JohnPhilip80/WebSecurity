package edu.cca.john.bankapp.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import edu.cca.john.bankapp.util.DBConnection;
import edu.cca.john.bankapp.util.UserData;
import jakarta.servlet.http.Cookie;

public class BankRepository {
	public Long authenticate(String userName, String password) throws Exception {
		Long userId = null;
		Connection con = DBConnection.getConnection();
		PreparedStatement ps = con.prepareStatement("SELECT * FROM users WHERE login_name=? AND login_password=?");
        ps.setString(1, userName);
        ps.setString(2, password);
        ResultSet rs = ps.executeQuery();
        if (rs.next())
        	userId = rs.getLong("user_id");
        return userId;
	}
	public void createSessionForUser(Long userId, String sessionId) throws Exception {
		Connection con = DBConnection.getConnection();
		PreparedStatement sessionPs = con.prepareStatement("INSERT INTO sessions(session_id, user_id) VALUES (?, ?)");
        sessionPs.setString(1, sessionId);
        sessionPs.setLong(2, userId);
        sessionPs.executeUpdate();
	}
	public UserData getUserDataBySessionId(String sessionId) throws Exception {
		UserData userData = null;
		Connection con = DBConnection.getConnection();
        PreparedStatement ps = con.prepareStatement("SELECT a.login_name, b.balance_amount FROM sessions c INNER JOIN users a ON c.user_id = a.user_id INNER JOIN accounts b ON c.user_id = b.user_id WHERE c.session_id=?");
        ps.setString(1, sessionId);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
        	userData = new UserData(rs.getString(1),rs.getLong(2));
        }
        return userData;
	}
	
	public void deleteSession(String sessionId) throws Exception {
		Connection con = DBConnection.getConnection();
        PreparedStatement ps = con.prepareStatement("DELETE FROM sessions WHERE session_id=?");
        ps.setString(1, sessionId);
        ps.executeUpdate();
	}
}
