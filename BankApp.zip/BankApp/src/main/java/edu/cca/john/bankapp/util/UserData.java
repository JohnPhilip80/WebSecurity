package edu.cca.john.bankapp.util;

public record UserData(String loginName, Long balanceAmount) {}
