package edu.cca.john.bankapp.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import edu.cca.john.bankapp.service.BankService;

@WebServlet("/Dashboard")
public class DashboardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BankService service = null;
    public DashboardController() {
        super();
        service = new BankService();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		service.getUserDataBySessionId(request, response);
	}
}
