package edu.cca.john.bankapp.service;

import java.util.UUID;
import edu.cca.john.bankapp.repository.BankRepository;
import edu.cca.john.bankapp.util.UserData;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class BankService {
	private BankRepository repo;
	public BankService() {
		repo = new BankRepository();
	}
	public void authenticate(HttpServletResponse response,String userName, String password) {
		Long userId = null;
		String sessionId = null;
		try {
			userId = repo.authenticate(userName, password);
			if(userId == null) 
        		response.getWriter().println("<h3>Invalid Credentials</h3>");
        	else {
        		sessionId = UUID.randomUUID().toString();
        		repo.createSessionForUser(userId, sessionId);
        		response.addCookie(new Cookie("SESSION_ID", sessionId));
        		response.sendRedirect("/BankApp/Dashboard");
        	}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	public String getSessionIdFromCookies(Cookie[] cookies) {
		String sessionId = null;
	    if (cookies != null) 
	        for (Cookie c : cookies) 
	            if (c.getName().equals("SESSION_ID"))
	                sessionId = c.getValue();
	    return sessionId;
	}
	public void getUserDataBySessionId(HttpServletRequest req, HttpServletResponse res) {
		String sessionId = null;
		UserData userData = null;
		sessionId = getSessionIdFromCookies(req.getCookies());
	    if (sessionId != null) {
	        try {
	        	userData = repo.getUserDataBySessionId(sessionId);
	        	req.setAttribute("userName", userData.loginName());
	    	    req.setAttribute("balanceAmount", userData.balanceAmount());
	    	    RequestDispatcher dispatcher = req.getRequestDispatcher("dashboard.jsp");
	    	    dispatcher.forward(req, res);
	        } catch (Exception e) {e.printStackTrace();}
	    }
	}
	public void logoutUser(HttpServletRequest req, HttpServletResponse res) {
		String sessionId = null;
        try {
	        sessionId = getSessionIdFromCookies(req.getCookies());
	        if(sessionId != null) {
	        	repo.deleteSession(sessionId);
	            Cookie cookie = new Cookie("SESSION_ID", "");
	            cookie.setMaxAge(0);
	            res.addCookie(cookie);
	            res.sendRedirect("/BankApp/Login");
	        }
        }catch(Exception ex) {ex.printStackTrace();}
	}
}
