<header>
	<nav class="navbar navbar-expand-sm bg-primary navbar-dark">
	    <ul class = "navbar-nav ml-auto">
	        <li class = "nav-item">
	            <a href="${pageContext.request.contextPath}/Home" class="navbar-brand"> CCA Bank </a>
	        </li>
	        <li class = "nav-item">
	            <a href="${pageContext.request.contextPath}/Dashboard" class="nav-link" >Dashboard</a>
	        </li>
	       <li class = "nav-item">
	           <a href="${pageContext.request.contextPath}/Transaction" class="nav-link" >Transaction</a>
	       </li>
	       <li class = "nav-item">
	           <a href="${pageContext.request.contextPath}/Chat" class="nav-link" >Chat</a>
	       </li>
	       <li class = "nav-item">
	           <a href="${pageContext.request.contextPath}/Accounts" class="nav-link" >Accounts</a>
	       </li>
	    </ul>
	    <ul class = "navbar-nav ms-auto">
	        <li class = "nav-item">
	            <a href="${pageContext.request.contextPath}/AboutUs" class="nav-link">About Us</a>
	        </li>
	        <li class = "nav-item">
	            <a href="${pageContext.request.contextPath}/ContactUs" class="nav-link" >Contact Us</a>
	        </li>
	        <li class = "nav-item">
	            <a href="${pageContext.request.contextPath}/Register" class="nav-link" >Register</a>
	        </li>
	        <li class = "nav-item">
	            <a href="${pageContext.request.contextPath}/Login" class="nav-link" >Login</a>
	        </li>
	       <li class = "nav-item">
	           <a href="${pageContext.request.contextPath}/Logout" class="nav-link" >Logout</a>
	       	</li>
		</ul>
	</nav>
</header>