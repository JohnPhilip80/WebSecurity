<footer class = "footer">
  <div class="container">
    <span>All Rights Reserved 2025 John Philip</span>
  </div>
</footer>