<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Mobile Shop - Home</title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
		<link href ="${pageContext.request.contextPath}/css/styles.css" rel="stylesheet"></link>
	</head>
	<body>
		<jsp:include page="parts/header.jsp" />		
		<div class = "container">
			<h1 class="text-center">Dashboard</h1>
			<h2>Welcome ${userName}</h2>
	    	<h2>Your Balance Amount: ${balanceAmount} </h2>
		</div>
		<jsp:include page="parts/footer.jsp" />	
	</body>
</html>