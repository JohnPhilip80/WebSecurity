<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Mobile Shop - Home</title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
		<link href ="${pageContext.request.contextPath}/css/styles.css" rel="stylesheet"></link>
	</head>
	<body>
		<jsp:include page="parts/header.jsp" />		
		<div class = "container">
			<h1 class="text-center">Login...</h1>
			<div class="container mt-5">
			    <div class="card" style="padding: 20px;">
			        <form action="Login" method="post">
			            <input type="text" class="form-control mb-3" id="userName" placeholder="Enter User Name">
			            <input type="password" class="form-control mb-3" id="password" placeholder="Enter Password">
			            <input type="submit" class="btn btn-outline-primary form-control rounded-0" value="Login">
			        </form>
			    </div>
			</div>
		</div>
		<jsp:include page="parts/footer.jsp" />	
	</body>
</html>

