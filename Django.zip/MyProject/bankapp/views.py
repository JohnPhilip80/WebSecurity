from django.http import HttpResponse
from django.shortcuts import render, redirect
#import data_repository as repo
import bankapp.db_repository as repo

def userlogin(request):
    if request.method == "POST":
        session_id = repo.userlogin(request)
        if session_id:
            response = redirect("bhomepage")
            response.set_cookie('SESSION_ID', session_id)
            return response
        else:
            return HttpResponse("Invalid credentials")
    else:
        return render(request,
                      "user_login.html",
                      {"user_role":repo.getuser(request)["role_name"]})

def userlogout(request):
    repo.deletesession(request.COOKIES.get('SESSION_ID'))
    response = redirect("buserlogin")
    response.delete_cookie('SESSION_ID')
    return response

def homepage(request):
    welcome_message = "Welcome to the CCA Bank. "
    user = repo.getuser(request)
    if user["role_name"] != "ROLE_PUBLIC":
        welcome_message += (user["login_name"] +
                            ". Your Account Balance is:" +
                            str(user["balance_amount"]))
    else:
        welcome_message += "You are not logged in. Please log in or register first."
    return render(request, "home_page.html",
                  {"welcome_message":welcome_message,
                   "user_role":user["role_name"]})

def addaccount(request):
    if request.method == "POST":
        repo.createaccount(request)
        return redirect("blistaccount")
    else:
        return render(request,
                      "account_form.html",
                      {"form_title":"Create New Account",
                       "user_role":repo.getuser(request)["role_name"]})

def updateaccount(request,id):
    if request.method == "POST":
        repo.updateaccount(request,id)
        return redirect("blistaccount")
    else:
        return render(request,
                      "account_form.html",
                      {"form_title":"Update Account",
                       "account":repo.readaccount(id),
                       "user_role":repo.getuser(request)["role_name"]})

def deleteaccount(request,id):
    repo.deleteaccount(id)
    return redirect("blistaccount")

def pagenotfound(request,exception):
    return render(request, "404.html",status=404)

def listaccount(request):
    return render(request,
                  "list_account.html",
                  {"accounts":repo.readaccounts,
                   "user_role":repo.getuser(request)["role_name"]})

def aboutus(request):
    return render(request,
                  "about_us.html",
                  {"user_role":repo.getuser(request)["role_name"]})

def contactus(request):
    return render(request,
                  "contact_us.html",
                  {"user_role":repo.getuser(request)["role_name"]})

def userregister(request):
    return render(request,
                  "user_register.html",
                  {"user_role":repo.getuser(request)["role_name"]})

def usertransaction(request):
    if request.method == "POST":
        repo.transfermoney(request)
        return redirect("bhomepage")
    else:
        return render(request,
                      "user_transaction.html",
                      {"user_role":repo.getuser(request)["role_name"]})

def userfeedback(request):
    if request.method == "POST":
        repo.addcomment(request);
        return redirect("buserfeedback")
    else:
        return render(request,
                      "user_feedback.html",
                      {"user_role":repo.getuser(request)["role_name"],
                       "user_comments":repo.getcomments(request)})
