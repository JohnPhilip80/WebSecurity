import uuid
from django.db import connection

def dictfetchall(cursor):
    columns = [col[0] for col in cursor.description]
    return [dict(zip(columns, row)) for row in cursor.fetchall()]

def createaccount(request):
    with connection.cursor() as cursor:
        cursor.execute("""
            INSERT INTO bank_accounts 
            (type_name, rate_of_interest, year_launched) 
            VALUES (%s, %s, %s)
        """,
            [request.POST["type_name"],
            request.POST["rate_of_interest"],
            request.POST["year_launched"]])

def readaccounts():
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM bank_accounts")
        accounts = dictfetchall(cursor)
    return accounts

def readaccount(id):
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT * FROM bank_accounts 
            WHERE id = %s
            """, [id])
        account = dictfetchall(cursor)[0]
    return account

def updateaccount(request,id):
    with connection.cursor() as cursor:
        cursor.execute("""
            UPDATE bank_accounts 
            SET type_name = %s, 
            rate_of_interest = %s, 
            year_launched = %s 
            WHERE id = %s
            """,
            [request.POST["type_name"],
             request.POST["rate_of_interest"],
             request.POST["year_launched"], id])

def deleteaccount(id):
    with connection.cursor() as cursor:
        cursor.execute("""
            DELETE FROM bank_accounts 
            WHERE id = %s
            """, [id])

def userlogin(request):
    with connection.cursor() as cursor1:
        cursor1.execute("""
            SELECT * FROM users 
            WHERE login_name = %s 
            AND login_password = %s
            """,
            [request.POST["login_name"],
             request.POST["login_password"]])
        result = dictfetchall(cursor1)
    if len(result) != 0:
        user = result[0]
        session_id = str(uuid.uuid4())
        with connection.cursor() as cursor2:
            cursor2.execute("""
                INSERT INTO sessions 
                (session_id, user_id) VALUES (%s, %s)
                """,
                [session_id, user["user_id"]])
        return session_id
    else:
        return None

def getuser(request):
    session_id = request.COOKIES.get('SESSION_ID')
    if session_id:
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT a.login_name,b.role_name,e.balance_amount 
                FROM user_role c 
                INNER JOIN users a ON c.user_id = a.user_id 
                INNER JOIN user_accounts e ON a.user_id = e.user_id 
                INNER JOIN roles b ON c.role_id = b.role_id
                INNER JOIN sessions d ON d.user_id = a.user_id 
                WHERE d.session_id = %s
                """, [session_id])
            return dictfetchall(cursor)[0]
    else:
        return {"login_name":"","balance_amount":0,"role_name":"ROLE_PUBLIC"}

def deletesession(session_id):
    with connection.cursor() as cursor:
        cursor.execute("""
            DELETE FROM sessions 
            WHERE session_id = %s
            """, [session_id])

def transfermoney(request):
    from_user = getuser(request)["login_name"]
    to_user = request.POST["to_user"]
    transfer_amount = request.POST["transfer_amount"]
    with connection.cursor() as cursor1:
        cursor1.execute("""
            UPDATE user_accounts 
            SET balance_amount = balance_amount - %s 
            WHERE user_id = (
            SELECT user_id 
            FROM db_bank.users 
            WHERE login_name= %s );
            """, [transfer_amount, from_user])
    with connection.cursor() as cursor2:
        cursor2.execute("""
            UPDATE user_accounts 
            SET balance_amount = balance_amount + %s 
            WHERE user_id = (
            SELECT user_id 
            FROM db_bank.users 
            WHERE login_name= %s );
            """,[transfer_amount, to_user])

def addcomment(request):
    with connection.cursor() as cursor:
        cursor.execute("""
            INSERT INTO user_comments
            (username, comment) 
            VALUES (%s, %s)
            """,
            [getuser(request)["login_name"],
             request.POST["user_comment"]])

def getcomments(request):
    user_comments = ""
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM user_comments")
        comments = dictfetchall(cursor)
    for comment in comments:
        user_comments = (user_comments +
                         "<p><b>" + comment["username"] +
                         ":</b> " + comment["comment"] +
                         "</p>")
    return user_comments

