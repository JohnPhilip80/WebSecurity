package edu.cca.john.ws.util;

public record UserData(String loginName, Long balanceAmount) {}
