package edu.cca.john.ws.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.UUID;

import jakarta.servlet.http.Cookie;

public class SessionUtil {
	
	public static String getSessionIdFromCookies(Cookie[] cookies) {
		String sessionId = null;
	    if (cookies != null) 
	        for (Cookie c : cookies) 
	            if (c.getName().equals("SESSION_ID"))
	                sessionId = c.getValue();
	    return sessionId;
	}

	public static Long authenticate(String userName, String password) throws Exception {
		Long userId = null;
		Connection con = DBConnection.getConnection();
		PreparedStatement ps = con.prepareStatement("SELECT * FROM users WHERE login_name=? AND login_password=?");
        ps.setString(1, userName);
        ps.setString(2, password);
        ResultSet rs = ps.executeQuery();
        if (rs.next())
        	userId = rs.getLong("user_id");
        return userId;
	}
	
	public static void createSessionForUser(Long userId, String sessionId) throws Exception {
		Connection con = DBConnection.getConnection();
		PreparedStatement sessionPs = con.prepareStatement("INSERT INTO sessions(session_id, user_id) VALUES (?, ?)");
        sessionPs.setString(1, sessionId);
        sessionPs.setLong(2, userId);
        sessionPs.executeUpdate();
	}
	
	public static void addComment(String sessionId, String userComment) throws Exception {
		String userName = getUserDataBySessionId(sessionId).loginName();
		Connection con = DBConnection.getConnection();
		PreparedStatement sessionPs = con.prepareStatement("INSERT INTO user_comments(username, comment) VALUES (?, ?)");
        sessionPs.setString(1, userName);
        sessionPs.setString(2, userComment);
        sessionPs.executeUpdate();
	}
	
	public static String getAllComments() throws Exception {
		String comments="";
		Connection con = DBConnection.getConnection();
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM user_comments");
        while(rs.next()){
            comments = comments + "<p><b>" + rs.getString("username") + ":</b> " + rs.getString("comment") + "</p>"; 
        }
        return comments;
	}
	
	public static UserData getUserDataBySessionId(String sessionId) throws Exception {
		UserData userData = null;
		Connection con = DBConnection.getConnection();
        PreparedStatement ps = con.prepareStatement("SELECT a.login_name, b.balance_amount FROM sessions c INNER JOIN users a ON c.user_id = a.user_id INNER JOIN accounts b ON c.user_id = b.user_id WHERE c.session_id=?");
        ps.setString(1, sessionId);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
        	userData = new UserData(rs.getString(1),rs.getLong(2));
        }
        return userData;
	}
	
	public static void removeSession(String sessionId) throws Exception {
		Connection con = DBConnection.getConnection();
        PreparedStatement ps = con.prepareStatement("DELETE FROM sessions WHERE session_id=?");
        ps.setString(1, sessionId);
        ps.executeUpdate();
	}
	
	public static void transferAmount(String sessionId,String toUser, String amount) throws Exception {
		String fromUser = getUserDataBySessionId(sessionId).loginName();
		Connection con = DBConnection.getConnection();
		con.setAutoCommit(false);
		PreparedStatement ps1 = con.prepareStatement("update db_bank.accounts set balance_amount = balance_amount - ? where user_id = (select user_id from db_bank.users where login_name= ? );");
		ps1.setDouble(1, Double.parseDouble(amount));
        ps1.setString(2, fromUser);
        ps1.executeUpdate();
        PreparedStatement ps2 = con.prepareStatement("update db_bank.accounts set balance_amount = balance_amount + ? where user_id = (select user_id from db_bank.users where login_name= ? );");
		ps2.setDouble(1, Double.parseDouble(amount));
        ps2.setString(2, toUser);
        ps2.executeUpdate();
        con.commit();
	}
}



















