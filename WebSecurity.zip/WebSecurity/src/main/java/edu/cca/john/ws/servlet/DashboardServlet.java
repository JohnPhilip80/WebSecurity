package edu.cca.john.ws.servlet;

import java.io.IOException;
import edu.cca.john.ws.util.SessionUtil;
import edu.cca.john.ws.util.UserData;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
@WebServlet("/Dashboard")
public class DashboardServlet extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		doGet(req,res);
	}
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		String sessionId = null;
		UserData userData = null;
		String userComments = null;
		sessionId = SessionUtil.getSessionIdFromCookies(req.getCookies());
	    if (sessionId != null) {
	        try {
	        	userData = SessionUtil.getUserDataBySessionId(sessionId);
	        	userComments = SessionUtil.getAllComments();
	        } catch (Exception e) {e.printStackTrace();}
	    }
	    req.setAttribute("userName", userData.loginName());
	    req.setAttribute("balanceAmount", userData.balanceAmount());
	    req.setAttribute("userComments", userComments);
	    RequestDispatcher dispatcher = req.getRequestDispatcher("dashboard.jsp");
	    dispatcher.forward(req, res);
	}
}
