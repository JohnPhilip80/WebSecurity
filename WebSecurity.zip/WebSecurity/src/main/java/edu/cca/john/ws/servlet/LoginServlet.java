package edu.cca.john.ws.servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.UUID;
import edu.cca.john.ws.util.SessionUtil;

@SuppressWarnings("serial")
@WebServlet("/CCABank")
public class LoginServlet extends HttpServlet {
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		RequestDispatcher dispatcher = req.getRequestDispatcher("login.jsp");
	    dispatcher.forward(req, res);
	}
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        Long userId = null;
        String sessionId = null;
        try {
        	userId = SessionUtil.authenticate(username, password);
        	if(userId == null) 
        		response.getWriter().println("<h3>Invalid Credentials</h3>");
        	else {
        		sessionId = UUID.randomUUID().toString();
        		SessionUtil.createSessionForUser(userId, sessionId);
        		response.addCookie(new Cookie("SESSION_ID", sessionId));
        		response.sendRedirect("/WebSecurity/Dashboard");
        	}
        }catch(Exception ex){
        	ex.printStackTrace();
        }
    }
}