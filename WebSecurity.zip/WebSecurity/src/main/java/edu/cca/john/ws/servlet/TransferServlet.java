package edu.cca.john.ws.servlet;
import java.io.IOException;
import edu.cca.john.ws.util.SessionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
@WebServlet("/TransferServlet")
public class TransferServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String toUser = request.getParameter("toUser");
        String transferAmount = request.getParameter("transferAmount");
        //String token = request.getParameter("csrfToken");
        String userComment = request.getParameter("userComment");
        String sessionId = null;
        try {
        	sessionId = SessionUtil.getSessionIdFromCookies(request.getCookies());
        	System.out.println("SessionId:" + sessionId);
        	SessionUtil.transferAmount(sessionId, toUser, transferAmount);
        	SessionUtil.addComment(sessionId,userComment);
        	response.sendRedirect("/WebSecurity/Dashboard");
        }catch(Exception ex) {ex.printStackTrace();}
	}
}
