from django.http import HttpResponse

def homepage(request):
    return HttpResponse("Show Mobile Store Home html page.")
def aboutus(request):
    return HttpResponse("Show Mobile Store About Us html page")
def contactus(request):
    return HttpResponse("Show Mobile Store Contact Us html page")
def listmobile(request):
    return HttpResponse("Show Mobile List html page")
def addmobile(request):
    return HttpResponse("Show Empty Mobile Form html page.")
def updatemobile(request,id):
    return HttpResponse(f"Show Mobile No: {id} detail in Mobile Form html page.")
def deletemobile(request,id):
    return HttpResponse(f"Delete Mobile No: {id} and redirect to Mobile List html page.")
def pagenotfound(request):
    return HttpResponse("Show 404.html page.")