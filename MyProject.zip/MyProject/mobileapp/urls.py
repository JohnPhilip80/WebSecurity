from django.urls import path
from mobileapp import views

urlpatterns = [
    path('home-page',views.homepage,name='mhomepage'),
    path('about-us',views.aboutus,name='maboutus'),
    path('contact-us',views.contactus,name='mcontactus'),
    path('list-mobile',views.listmobile,name='mlistmobile'),
    path('add-mobile',views.addmobile,name='maddmobile'),
    path('update-mobile/<int:id>',views.updatemobile,name='mupdatemobile'),
    path('delete-mobile/<int:id>',views.deletemobile,name='mdeletemobile'),
    path('page-not-found',views.pagenotfound,name='mpagenotfound')
]