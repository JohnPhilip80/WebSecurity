from mcp.server.fastmcp import FastMCP
from api_manager import login_transfer_logout, login_balance_logout, create_account_type,read_account_type,read_account_types,update_account_type,delete_account_type

mcp = FastMCP("ccabank-tools",stateless_http=True)


@mcp.tool()
def login_transfer_logout_tool(login_name: str, login_password: str, to_user: str, transfer_amount: int):
    return login_transfer_logout(login_name, login_password, to_user, transfer_amount)

@mcp.tool()
def login_balance_logout_tool(login_name: str, login_password: str):
    return login_balance_logout(login_name, login_password)

@mcp.tool()
def create_account_type_tool(type_name,rate_of_interest,year_launched):
    return create_account_type(type_name,rate_of_interest,year_launched)

@mcp.tool()
def update_account_type_tool(type_name,rate_of_interest,year_launched,id):
    return update_account_type(type_name,rate_of_interest,year_launched,id)

@mcp.tool()
def read_all_account_types_tool():
    return read_account_types()

@mcp.tool()
def read_single_account_type_tool(id):
    return read_account_type(id)

@mcp.tool()
def delete_account_type_tool(id):
    return delete_account_type(id)


if __name__ == "__main__":
    mcp.run()