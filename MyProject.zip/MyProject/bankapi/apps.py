from django.apps import AppConfig


class BankapiConfig(AppConfig):
    name = 'bankapi'
