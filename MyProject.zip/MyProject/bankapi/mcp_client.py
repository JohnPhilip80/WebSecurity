import asyncio
from google import genai
from mcp.client.stdio import stdio_client, StdioServerParameters
from mcp import ClientSession

client = genai.Client(api_key="AIzaSyCH2vd5pVy9IODgYeLhLXu5oAITRPHLob8")

async def llm_gemini(prompt):
    server = StdioServerParameters(
        command="python",
        args=["mcp_server.py"]
    )

    async with stdio_client(server) as (r, w):
        async with ClientSession(r, w) as session:
            await session.initialize()

            mcp_tools = await session.list_tools()

            tools = [{
                "function_declarations": [
                    {
                        "name": t.name,
                        "description": t.description or "MCP tool",
                        "parameters": t.inputSchema
                    }
                    for t in mcp_tools.tools
                ]
            }]

            response = client.models.generate_content(
                model="gemini-2.5-flash",
                contents=prompt,
                config={"tools": tools}
            )

            part = response.candidates[0].content.parts[0]

            if hasattr(part, "function_call"):
                print("Executing MCP tool:", part.function_call.name)

                result = await session.call_tool(
                    part.function_call.name,
                    dict(part.function_call.args)
                )
                #return result

                if result.content:
                    items = result.content
                    for item in items:
                        print(f"{item.text}")
                else:
                    print(result)


asyncio.run(llm_gemini("Show all account types"))