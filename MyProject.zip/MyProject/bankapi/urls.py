from django.urls import path

from bankapi import views

urlpatterns = [
    path('authentication/', views.authentication),
    path('accounts/',views.accounts),
    path('accounts/<int:id>',views.accountdetail),
    path('dashboard/',views.dashboard),
    path('transfer/',views.transfer),
    path('balance/',views.balance),
    path('feedback/',views.feedback),
    path('prompting/',views.prompting)
]