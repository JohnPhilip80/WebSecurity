from asgiref.sync import async_to_sync
import asyncio
from django.shortcuts import render

import bankapp.db_repository as repo
from django.http import JsonResponse, HttpResponse
import json

#from bankapi.mcp_client import llm_gemini

"""
import asyncio
from google import genai
from mcp.client.stdio import stdio_client, StdioServerParameters
from mcp import ClientSession
"""
from bankapi.gemini_client import chat


def authentication(request):
    if request.method == "POST":
        body = json.loads(request.body)
        session_id = repo.userlogin(
            {"login_name":body.get("login_name"),
            "login_password":body.get("login_password")})
        if session_id:
            response = HttpResponse("Logged in Successfully")
            response.set_cookie("SESSION_ID",session_id)
            return response
        else:
            return JsonResponse({"message":"Invalid Credentials"})
    elif request.method == "DELETE":
        repo.deletesession(request.COOKIES.get("SESSION_ID"))
        response=HttpResponse("Session Id deleted")
        response.delete_cookie("SESSION_ID")
        return response
    else:
        return JsonResponse({"message":"Invalid Request"})

def accounts(request):
    """
    session_id = request.COOKIES.get("SESSION_ID")
    if not session_id:
        return JsonResponse({"message": "Unauthenticated"})
    elif repo.getuser(session_id)["role_name"] != "ROLE_ADMIN":
        return JsonResponse({"message": "Unauthorized"})
    """
    if request.method == "GET":
        return JsonResponse(repo.readaccounts(), safe=False)
    elif request.method == "POST":
        body = json.loads(request.body)
        repo.createaccount({"type_name":body.get("type_name"),
                   "rate_of_interest":body.get("rate_of_interest"),
                   "year_launched":body.get("year_launched")})
        return JsonResponse({"message": "Account created Successfully"})
    else:
        return JsonResponse({"message": "Invalid Request"})

def accountdetail(request,id):
    """
    session_id = request.COOKIES.get("SESSION_ID")
    if not session_id:
        return JsonResponse({"message": "Unauthenticated"})
    elif repo.getuser(session_id)["role_name"] != "ROLE_ADMIN":
        return JsonResponse({"message": "Unauthorized"})
    """
    if request.method == "GET":
        acc = repo.readaccount(id)
        return JsonResponse(acc, safe=False)
    elif request.method == "PUT":
        body = json.loads(request.body)
        repo.updateaccount({"type_name":body.get("type_name"),
                   "rate_of_interest":body.get("rate_of_interest"),
                   "year_launched":body.get("year_launched")},id)
        return JsonResponse({"message": "Account updated"})
    elif request.method == "DELETE":
        repo.deleteaccount(id)
        return JsonResponse({"message": "Account deleted"})
    else:
        return JsonResponse({"message": "Invalid Request"})

def transfer(request):
    session_id = request.COOKIES.get("SESSION_ID")
    print(request.method)
    if not session_id:
        return JsonResponse({"message": "Unauthenticated"})
    elif repo.getuser(session_id)["role_name"] != "ROLE_CUSTOMER":
        return JsonResponse({"message": "Unauthorized"})
    elif request.method == "POST":
        body = json.loads(request.body)
        repo.transfermoney(session_id,
                           {"to_user":body.get("to_user"),
                            "transfer_amount":body.get("transfer_amount")})
        return JsonResponse({"message": "Amount Transferred Successfully"})
    else:
        return JsonResponse({"message": "Invalid Request"})
def balance(request):
    session_id = request.COOKIES.get("SESSION_ID")
    if not session_id:
        return JsonResponse({"message": "Unauthenticated"})
    else:
        return JsonResponse({"Balance": repo.getuserbalance(session_id)})

def dashboard(request):
    session_id = request.COOKIES.get("SESSION_ID")
    if not session_id:
        return JsonResponse({"message": "Unauthenticated"})
    elif request.method == "GET":
        return JsonResponse(repo.getuser(session_id), safe=False)
    else:
        return JsonResponse({"message": "Invalid Request"})

def feedback(request):
    session_id = request.COOKIES.get("SESSION_ID")
    if not session_id:
        return JsonResponse({"message": "Unauthenticated"})
    elif repo.getuser(session_id)["role_name"] != "ROLE_CUSTOMER":
        return JsonResponse({"message": "Unauthorized"})
    elif request.method == "POST":
        body = json.loads(request.body)
        repo.addcomment(session_id,
                        {"user_comment":body.get("user_comment")})
        return JsonResponse({"message": "Comment added Successfully"})
    elif request.method == "GET":
        comments = repo.getcomments()
        return JsonResponse(comments, safe=False)
    else:
        return JsonResponse({"message": "Invalid Request"})

async def prompting(request):
    try:
        response_text = None
        if request.method == "POST":
            prompt = request.POST.get("prompt")
            print(prompt)
            response_text =  chat(prompt)
            pretty_json = json.dumps(response_text, indent=4)
            return render(request, "mcp_prompt.html", {
                "response": pretty_json
            })
        else:
            return render(request, "mcp_prompt.html", {
                "response": response_text
            })

    except Exception as e:
        return JsonResponse({"status": "error", "message": str(e)}, status=500)

    """
    try:
        client = genai.Client(api_key="AIzaSyCH2vd5pVy9IODgYeLhLXu5oAITRPHLob8")
        response_text = None
        if request.method == "POST":
            prompt = request.POST.get("prompt")
            print(prompt)
            server = StdioServerParameters(
                command="python",
                args=["mcp_server.py"]
            )
            async with stdio_client(server) as (r, w):
                print("One")
                async with ClientSession(r, w) as session:
                    print("Two")
                    await session.initialize()
                    print("checking...")
                    mcp_tools = await session.list_tools()
                    tools = [{
                        "function_declarations": [
                            {
                                "name": t.name,
                                "description": t.description or "MCP tool",
                                "parameters": t.inputSchema
                            }
                            for t in mcp_tools.tools
                        ]
                    }]
                    response = client.models.generate_content(
                        model="gemini-2.5-flash",
                        contents=prompt,
                        config={"tools": tools}
                    )
                    part = response.candidates[0].content.parts[0]
                    if hasattr(part, "function_call"):
                        print("Executing MCP tool:", part.function_call.name)
                        response_text = await session.call_tool(
                            part.function_call.name,
                            dict(part.function_call.args)
                        )
                        return JsonResponse({"status": "success", "data": response_text.content})
        else:
            return render(request, "mcp_prompt.html", {
                "response": response_text
            })
    except Exception as e:
        return JsonResponse({"status": "error", "message": str(e)}, status=500)
    """
