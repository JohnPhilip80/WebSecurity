from bankapi.api_manager import login_transfer_logout, login_balance_logout, create_account_type,read_account_types,read_account_type,update_account_type,delete_account_type
def execute_tool(name,args):
    if name == "Login_Transfer_Logout":
        return login_transfer_logout(args["login_name"],args["login_password"], args["to_user"], args["transfer_amount"])
    elif name == "Login_Balance_Logout":
        return login_balance_logout(args["login_name"],args["login_password"])
    elif name == "Insert_Account_Type":
        return create_account_type(args["type_name"], args["rate_of_interest"], args["year_launched"])
    elif name == "Read_All_Account_Types":
        return read_account_types()
    elif name == "Read_Single_Account_Type":
        return read_account_type(args["id"])
    elif name == "Update_Account_Type":
        return update_account_type(args["type_name"], args["rate_of_interest"], args["year_launched"], args["id"])
    elif name == "Delete_Account_Type":
        return delete_account_type(args["id"])
    else:
        return None
    """
    elif name == "Create_Account_Type":
        return create_account_type(args["type_name"],args["rate_of_interest"],args["year_launched"])
    elif name == "Read_All_Account_Types":
        return read_account_types()
    elif name == "Read_Single_Account_Type":
        return read_account_type(args["id"])
    elif name == "Update_Account_Type":
        return update_account_type(args["type_name"],args["rate_of_interest"],args["year_launched"],args["id"])
    elif name == "Delete_Account_Type":
        return delete_account_type(args["id"])
    """
