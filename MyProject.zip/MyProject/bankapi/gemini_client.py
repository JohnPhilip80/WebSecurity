from google import genai
from bankapi.tool_executor import execute_tool

client = genai.Client(api_key="AIzaSyCH2vd5pVy9IODgYeLhLXu5oAITRPHLob8")

tools = [{
    "function_declarations": [
        {
            "name": "Login_Transfer_Logout",
            "description": "Login to site with login name and login password. Transfer Amount to other user. Logout from site",
            "parameters": {
                "type": "object",
                "properties": {
                    "login_name": {"type": "string"},
                    "login_password": {"type": "string"},
                    "to_user": {"type": "string"},
                    "transfer_amount": {"type": "integer"}
                },
                "required": ["login_name", "login_password", "to_user", "transfer_amount"]
            }
        },
        {
            "name": "Login_Balance_Logout",
            "description": "Login to site with login name and login password. Check the Balance Amount. Logout from site",
            "parameters": {
                "type": "object",
                "properties": {
                    "login_name": {"type": "string"},
                    "login_password": {"type": "string"},
                },
                "required": ["login_name", "login_password"]
            }
        },
        {
            "name": "Insert_Account_Type",
            "description": "Insert new account type ",
            "parameters": {
                "type": "object",
                "properties": {
                    "type_name": {"type": "string"},
                    "rate_of_interest": {"type": "number"},
                    "year_launched": {"type": "integer"}
                },
                "required": ["type_name", "rate_of_interest", "year_launched"]
            }
        },
        {
            "name": "Read_All_Account_Types",
            "description": "Read all account types",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": []
            }
        },
        {
            "name": "Read_Single_Account_Type",
            "description": "Read single account type",
            "parameters": {
                "type": "object",
                "properties": {
                    "id": {"type": "integer"}
                },
                "required": ["id"]
            }
        },
        {
            "name": "Update_Account_Type",
            "description": "Update existing account type ",
            "parameters": {
                "type": "object",
                "properties": {
                    "type_name": {"type": "string"},
                    "rate_of_interest": {"type": "number"},
                    "year_launched": {"type": "integer"},
                    "id": {"type": "integer"}
                },
                "required": ["type_name", "rate_of_interest", "year_launched","id"]
            }
        },
    {
            "name": "Delete_Account_Type",
            "description": "Delete a account type",
            "parameters": {
                "type": "object",
                "properties": {
                    "id": {"type": "integer"}
                },
                "required": ["id"]
            }
        },
    ]
}]

def chat(prompt):
    response = client.models.generate_content(
        model="gemini-2.5-flash",
        contents=prompt,
        config={
            "tools": tools
        }
    )

    candidate = response.candidates[0]
    part = candidate.content.parts[0]

    if hasattr(part, "function_call"):
        name = part.function_call.name
        args = dict(part.function_call.args)

        result = execute_tool(name, args)

        #print("Tool:", name)
        #print("Result:", result)
        return result
    else:
        #print(response.text)
        return response.text

#chat("Login with Saraswathy as username and sara as password. Transfer money 5000 to BalaMurugan. Logout from site")
#chat("Login with JohnPhilip as username and john as password. Show my balance amount. Logout from site")
#chat("show all account types")
#chat("read single account type for id 5")
#chat("Create a account type with type name = Testing Account, rate of interest = 9.4 and year launched = 2000")
#chat("update account type set type name as Home Loan Account, rate of interest as 9.9 and year launched as 1966 for id  4")
#chat("Delete acount type of id 11")