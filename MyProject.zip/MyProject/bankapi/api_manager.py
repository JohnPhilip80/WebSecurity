import requests

class APIManager:
    def __init__(self):
        self.session = requests.Session()
        self.base_url = "http://localhost:8000/bankapi"
        self.custom_headers = {
            "Content-Type": "application/json"
        }
    def logout(self):
        logout_url = f"{self.base_url}/authentication/"
        response = self.session.delete(
            logout_url,
            headers=self.custom_headers
        )
        if response.status_code == 200:
            print("Log out successful")
            return {
                "status": "success"
            }
        else:
            print("Log out failed")
            return {
                "status": "failed"
            }

    def login(self, username, password):
        login_url = f"{self.base_url}/authentication/"

        payload = {
            "login_name": username,
            "login_password": password
        }

        response = self.session.post(
            login_url,
            json=payload,
            headers=self.custom_headers
        )

        if response.status_code == 200:
            print("Login successful")

            # Extract cookies manually (if needed)
            cookies = self.session.cookies.get_dict()
            print("Cookies:", cookies)

            return {
                "status": "success",
            }
        else:
            print("Login failed:", response.text)
            return {
                "status": "failed",
                "error": response.text
            }
    def check_balance(self):
        api_url = f"{self.base_url}/balance/"
        cookies = self.session.cookies.get_dict()
        response = self.session.get(
            api_url,
            headers=self.custom_headers,
            cookies=cookies
        )
        if response.status_code == 200:
            print("API call successful")
            return response.json()
        else:
            print("API call failed:", response.text)
            return None

    def transfer_amount(self,to_user,transfer_amount):
        api_url = f"{self.base_url}/transfer/"

        # You can also manually attach cookies if required
        cookies = self.session.cookies.get_dict()
        payload = {
            "to_user": to_user,
            "transfer_amount": transfer_amount
        }
        response = self.session.post(
            api_url,
            json=payload,
            headers=self.custom_headers,
            cookies=cookies   # optional (session already handles this)
        )

        if response.status_code == 200:
            print("API call successful")
            return response.json()
        else:
            print("API call failed:", response.text)
            return None



# 🔹 Gemini MCP Tool Style Wrapper
def login_transfer_logout(login_name: str, login_password: str,to_user: str,transfer_amount: int):
    client = APIManager()

    login_result = client.login(login_name, login_password)
    if login_result["status"] != "success":
        return login_result
    data = client.transfer_amount(to_user,transfer_amount)
    logout_result = client.logout()

    return {
        "login": login_result,
        "data": data,
        "logout": logout_result
    }

def login_balance_logout(login_name: str, login_password: str):
    client = APIManager()

    login_result = client.login(login_name, login_password)
    if login_result["status"] != "success":
        return login_result
    data = client.check_balance()
    logout_result = client.logout()
    return {
        "data": data
    }

def create_account_type(type_name,rate_of_interest,year_launched):
    response = requests.Session().post(
        "http://localhost:8000/bankapi/accounts/",
        json={
            "type_name": type_name,
            "rate_of_interest": rate_of_interest,
            "year_launched": year_launched
        },
        headers={
            "Content-Type": "application/json"
        }
    )
    if response.status_code == 200:
        return response.json()
    else:
        return None

def read_account_types():
    response = requests.Session().get(
        "http://localhost:8000/bankapi/accounts/",
        headers={
            "Content-Type": "application/json"
        }
    )
    if response.status_code == 200:
        return response.json()
    else:
        return None

def read_account_type(id):
    print("id = ",id)
    response = requests.Session().get(
        "http://localhost:8000/bankapi/accounts/"+ str(id),
        headers={
            "Content-Type": "application/json"
        }
    )
    if response.status_code == 200:
        return response.json()
    else:
        return None

def update_account_type(type_name,rate_of_interest,year_launched,id):
    response = requests.Session().put(
        "http://localhost:8000/bankapi/accounts/" + str(id),
        json={
            "type_name": type_name,
            "rate_of_interest": rate_of_interest,
            "year_launched": year_launched,
        },
        headers={
            "Content-Type": "application/json"
        }
    )
    if response.status_code == 200:
        return response.json()
    else:
        return None

def delete_account_type(id):
    response = requests.Session().delete(
        "http://localhost:8000/bankapi/accounts/" + str(id),
        headers={
            "Content-Type": "application/json"
        }
    )
    if response.status_code == 200:
        return response.json()
    else:
        return None
"""

# 🔹 Run
if __name__ == "__main__":
    result = gemini_mcp_tool("Saraswathy", "sara","BalaMurugan",5000)
    print(result)

"""