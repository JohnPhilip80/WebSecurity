from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('bank/', include('bankapp.urls')),
    path('mobile/',include('mobileapp.urls')),
    path('bankapi/',include('bankapi.urls')),
]
