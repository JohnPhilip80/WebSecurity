<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>
	<div style="display:flex;height: 100vh;">
	  <div style="flex:1; padding:20px;">
	  	<h2>Welcome ${userName} to Dashboard</h2>
	    <h2>Your Balance Amount: ${balanceAmount} </h2>
	    <form action="TransferServlet" method="post">
	    	<input value="${userName}" type="hidden" name="fromUser"/><br/><br/>
	        To User: <input type="text" name="toUser"/><br/><br/>
	        Transfer Amount: <input type="text" name="transferAmount"/><br/><br/>
	        Comments: <input type="text" name="userComment" /><br/><br/>
	        <input type="hidden" name="csrfToken" value="${csrfToken}"/>
	        <input type="submit" value="Transfer"/>
	    </form>
	    <a href="LogoutServlet">Logout</a>
	  </div>
	  <div style="flex:1; padding:20px;">
	  	<h1>Comments</h1>
	  	<h3>${userComments}</h3>
	  </div>
	</div>
</body>
</html>