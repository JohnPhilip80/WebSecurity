package edu.cca.john.banking.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import edu.cca.john.banking.util.CSRFUtil;
import edu.cca.john.banking.util.SessionUtil;

@SuppressWarnings("serial")
@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String sessionId = null;
        try {
	        sessionId = SessionUtil.getSessionIdFromCookies(request.getCookies());
	        if(sessionId != null) {
	        	CSRFUtil.deleteToken(sessionId);
	        	SessionUtil.removeSession(sessionId);
	        	// Remove cookie
	            Cookie cookie = new Cookie("SESSION_ID", "");
	            cookie.setMaxAge(0);
	            response.addCookie(cookie);
	            response.sendRedirect("/Banking/CCABank");
	        }
        }catch(Exception ex) {ex.printStackTrace();}
    }
}