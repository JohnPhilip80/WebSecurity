package edu.cca.john.banking.servlet;
import java.io.IOException;
import edu.cca.john.banking.util.CSRFUtil;
import edu.cca.john.banking.util.SessionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
@WebServlet("/TransferServlet")
public class TransferServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String toUser = request.getParameter("toUser");
        String transferAmount = request.getParameter("transferAmount");
        String token = request.getParameter("csrfToken");
        String userComment = request.getParameter("userComment");
        String sessionId = null;
        try {
        	sessionId = SessionUtil.getSessionIdFromCookies(request.getCookies());
        	System.out.println("SessionId:" + sessionId);
        	if (!CSRFUtil.validateToken(token, sessionId)) {
        		System.out.println("CSRF Validation failed!");
                response.getWriter().println("CSRF validation failed!");
                return;
            }
        	else {
        		SessionUtil.transferAmount(sessionId, toUser, transferAmount);
        		SessionUtil.addComment(sessionId,userComment);
        		response.sendRedirect("/Banking/Dashboard");
        	}
        }catch(Exception ex) {ex.printStackTrace();}
	}
}
