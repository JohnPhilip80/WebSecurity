package edu.cca.john.banking.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.UUID;

public class CSRFUtil {

    public static String generateToken() {
        return UUID.randomUUID().toString();
    }

    public static void createToken(String token, String sessionId) throws Exception {
        Connection con = DBConnection.getConnection();

        PreparedStatement ps = con.prepareStatement(
            "INSERT INTO csrf_tokens(token, session_id) VALUES (?, ?)"
        );
        ps.setString(1, token);
        ps.setString(2, sessionId);
        ps.executeUpdate();

        con.close();
    }
    public static String readToken(String sessionId) throws Exception {
    	String csrfToken = null;
    	Connection con = DBConnection.getConnection();
        PreparedStatement ps = con.prepareStatement("SELECT * FROM csrf_tokens WHERE session_id=?");
        ps.setString(1, sessionId);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) csrfToken = rs.getString(1);
        con.close();
        return csrfToken;
    }
    public static boolean validateToken(String token, String sessionId) throws Exception {
        Connection con = DBConnection.getConnection();

        PreparedStatement ps = con.prepareStatement(
            "SELECT * FROM csrf_tokens WHERE token=? AND session_id=?"
        );
        ps.setString(1, token);
        ps.setString(2, sessionId);

        ResultSet rs = ps.executeQuery();

        boolean valid = rs.next();

        con.close();
        return valid;
    }
    public static void deleteToken(String sessionId) throws Exception{
    	try (Connection con = DBConnection.getConnection()) {

            PreparedStatement ps = con.prepareStatement(
                "DELETE FROM csrf_tokens WHERE session_id=?"
            );
            ps.setString(1, sessionId);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
