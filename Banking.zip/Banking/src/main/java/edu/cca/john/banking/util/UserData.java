package edu.cca.john.banking.util;

public record UserData(String loginName, Long balanceAmount) {}
